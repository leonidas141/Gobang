# Gobang
An abstract strategy board game

[中文版](../master/README-ZH_CN.md)
## Introduction
Gobang is an abstract strategy board game. Also called Gomoku or Five in a Row, it is traditionally played with Go pieces (black and white stones) on a go board with 19x19 (15x15) intersections;[1] however, because pieces are not moved or removed from the board, gomoku may also be played as a paper and pencil game. This game is known in several countries under different names.

Black plays first if white did not win in the previous game, and players alternate in placing a stone of their color on an empty intersection. The winner is the first player to get an unbroken row of five stones horizontally, vertically, or diagonally.
##About this program
This program is to realize human-computer competing in a single function `player`

##
